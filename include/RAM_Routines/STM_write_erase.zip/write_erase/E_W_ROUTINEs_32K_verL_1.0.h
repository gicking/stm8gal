unsigned char STM8_Routines_E_W_ROUTINEs_32K_verL_1_0_s19[] = {
};
unsigned int STM8_Routines_E_W_ROUTINEs_32K_verL_1_0_s19_len = 0;
